package DSAproject;

import java.util.*;


public class AirlineReservationSystem {
	static class Flight{
		int id;
		String name;
		String destination;
		
        Flight(int id, String name, String destination) {
            this.id = id;
            this.name = name;
            this.destination = destination;
	}
        public String toString() {
            return "[" + id + "] " + name + " = " + destination;
        }
	}
        static class Passenger{
        	int age;
        	String name;
        	
            Passenger(String name, int age) {
                this.name = name;
                this.age = age;
            }
            public String toString() {
                return name + " (" + age + ")";
            }
        }
        static Flight[] flight = new Flight[100];
        static int flightcount = 0;
        
        static class FlightNode{
        	Flight flight;
            FlightNode next;
            FlightNode prev;
            
            FlightNode(Flight f){
            	this.flight=f;	
        }
      }
        static FlightNode flightHead = null;
        
        static class PassengerNode {
            Passenger passenger;
            PassengerNode next;
            PassengerNode(Passenger p) {
            	this.passenger = p;
            }
        static Map<Integer, PassengerNode> flightPassengers = new HashMap<>(); 
        
        static Stack<String> undoStack = new Stack<>();
        static void addFlight(Flight f) {
            flight[flightcount++] = f;  
            addFlightToDoublyList(f);
            System.out.println("Added Flight: " + f);
        }
        static void addFlightToDoublyList(Flight f) {
            FlightNode node = new FlightNode(f);
            if (flightHead == null) {
                flightHead = node;
                return;
            }
         FlightNode temp = flightHead;
         while (temp.next != null) temp = temp.next;
         temp.next = node;
         node.prev = temp;
        }
        static void printFlightsForward() {
            System.out.println("\nFlights (Forward):");
            FlightNode temp = flightHead;
            while (temp != null) {
                System.out.println(temp.flight);
                temp = temp.next;
            }
        }
       
        static void printFlights() {
            System.out.println("\nAll Flights:");
            for (int i = 0; i < flightcount; i++) {
                System.out.println(flight[i]);
            }
        }

        static Flight searchFlight(String destination) {
            for (int i = 0; i < flightcount; i++) {
                if (flight[i].destination.equalsIgnoreCase(destination))
                    return flight[i];
            }
            return null;
        }
        static void bookPassenger(int flightID, Passenger p) {
            PassengerNode newNode = new PassengerNode(p);
            PassengerNode head = flightPassengers.get(flightID);
            newNode.next = head;
            flightPassengers.put(flightID, newNode);
            undoStack.push("Booked: " + p.name + " on Flight " + flightID);
            System.out.println("Passenger Booked: " + p + " on Flight " + flightID);
        }

        static void cancelPassenger(int flightID, String passengerName) {
            PassengerNode head = flightPassengers.get(flightID);
            if (head == null) {
                System.out.println("No passengers on this flight.");
                return;
            }

            PassengerNode curr = head, prev = null;
            while (curr != null) {
                if (curr.passenger.name.equalsIgnoreCase(passengerName)) {

                    if (prev == null)
                        flightPassengers.put(flightID, curr.next);
                    else
                        prev.next = curr.next;

                    undoStack.push("Cancelled Passenger " + passengerName + " from Flight " + flightID);
                    System.out.println("Cancelled booking of " + passengerName);
                    return;
                }
                prev = curr;
                curr = curr.next;
            }
            System.out.println("Passenger not found.");
        }
        static void printPassengers(int flightID) {
            System.out.println("\nPassengers for Flight " + flightID + ":");
            PassengerNode temp = flightPassengers.get(flightID);
            if (temp == null) { 
            	System.out.println("No passengers."); 
            	return; 
            	}
            while (temp != null) {
                System.out.println(temp.passenger);
                temp = temp.next;
            }
        }
        static void undoLastAction() {
            if (undoStack.isEmpty()) {
                System.out.println("\n Nothing to undo!");
            } else {
                String action = undoStack.pop();
                System.out.println("\nUndo: " + action);
            }
        }
        static int countPassengersRecursive(PassengerNode node) {
            if (node == null) 
            	return 0;
            return 1 + countPassengersRecursive(node.next);
        }
        static Passenger searchPassengerRecursive(PassengerNode node, String name) {
            if (node == null)
            	return null;
            if (node.passenger.name.equalsIgnoreCase(name))
            	return node.passenger;
            return searchPassengerRecursive(node.next, name);
        }
        static Passenger searchPassengerIterative(int flightID, String name) {
            PassengerNode temp = flightPassengers.get(flightID);
            while (temp != null) {
                if (temp.passenger.name.equalsIgnoreCase(name))
                    return temp.passenger;
                temp = temp.next;
            }
            return null;
        }

        static void updateFlight(int flightID, String name, String dest) {
            for (int i = 0; i < flightcount; i++) {
                if (flight[i].id == flightID) {
                    flight[i].name = name;
                    flight[i].destination = dest;
                    undoStack.push("Updated Flight " + flightID);
                    System.out.println("Flight Updated: " + flight[i]);
                    return;
                }
            }
            System.out.println("Flight not found.");
        }

       
        static void deleteFlight(int id) {
            deleteFlightArray(id);
            deleteFlightDLL(id);
            flightPassengers.remove(id);

            undoStack.push("Deleted Flight " + id);
            System.out.println("Flight " + id + " deleted.");
        }

        static void deleteFlightArray(int id) {
            for (int i = 0; i < flightcount; i++) {
                if (flight[i].id == id) {
                    for (int j = i; j < flightcount - 1; j++)
                        flight[j] = flight[j + 1];
                    flightcount--;
                    return;
                }
            }
        }

        static void deleteFlightDLL(int id) {
            FlightNode t = flightHead;

            while (t != null) {
                if (t.flight.id == id) {

                    if (t.prev != null)
                        t.prev.next = t.next;
                    else
                        flightHead = t.next;

                    if (t.next != null)
                        t.next.prev = t.prev;

                    return;
                }
                t = t.next;
            }
        }

       
        static void sortFlightsByID() {
            for (int i = 0; i < flightcount - 1; i++) {
                for (int j = 0; j < flightcount - i - 1; j++) {
                    if (flight[j].id > flight[j + 1].id) {
                        Flight temp = flight[j];
                        flight[j] = flight[j + 1];
                        flight[j + 1] = temp;
                    }
                }
            }
            System.out.println("Flights sorted by ID.");
        }

        static void sortFlightsByDestination() {
            for (int i = 0; i < flightcount - 1; i++) {
                for (int j = 0; j < flightcount - i - 1; j++) {
                    if (flight[j].destination.compareToIgnoreCase(flight[j + 1].destination) > 0) {
                        Flight temp = flight[j];
                        flight[j] = flight[j + 1];
                        flight[j + 1] = temp;
                    }
                }
            }
            System.out.println("Flights sorted by Destination.");
        }


        
        static int totalPassengersAllFlights() {
            int t = 0;
            for (int id : flightPassengers.keySet())
                t += countPassengersRecursive(flightPassengers.get(id));
            return t;
        }

        static void mostBookedFlight() {
            int max = -1, id = -1;

            for (int f : flightPassengers.keySet()) {
                int c = countPassengersRecursive(flightPassengers.get(f));
                if (c > max) {
                    max = c;
                    id = f;
                }
            }

            if (id == -1) System.out.println("No passengers booked.");
            else System.out.println("Most booked flight = " + id + " | Passengers = " + max);
        }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

        addFlight(new Flight(101, "FlyJinnah", "Karachi"));
        addFlight(new Flight(102, "PIA", "Lahore"));
        addFlight(new Flight(103, "AirSial", "Islamabad"));

        while (true) {
            System.out.println("\n===== AIRLINE RESERVATION MENU =====");
            System.out.println("1. Add Flight");
            System.out.println("2. Delete Flight");
            System.out.println("3. Update Flight");
            System.out.println("4. Print All Flights");
            System.out.println("5. Sort Flights");
            System.out.println("6. Book Passenger");
            System.out.println("7. Cancel Passenger Booking");
            System.out.println("8. Print Passengers");
            System.out.println("9. Search Passenger");
            System.out.println("10. Total Passengers");
            System.out.println("11. Most Booked Flight");
            System.out.println("12. Undo Last Action");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            int ch = sc.nextInt();

            switch (ch) {

                case 1:
                    System.out.print("Enter Flight ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Flight Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Destination: ");
                    String dest = sc.nextLine();
                    addFlight(new Flight(id, name, dest));
                    break;

                case 2:
                    System.out.print("Enter Flight ID to delete: ");
                    deleteFlight(sc.nextInt());
                    break;

                case 3:
                    System.out.print("Enter Flight ID: ");
                    int fid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("New Name: ");
                    String nn = sc.nextLine();
                    System.out.print("New Destination: ");
                    String nd = sc.nextLine();
                    updateFlight(fid, nn, nd);
                    break;

                case 4:
                    printFlights();
                    break;

                case 5:
                    System.out.println("1. Sort by ID\n2. Sort by Destination");
                    int s = sc.nextInt();
                    if (s == 1) sortFlightsByID();
                    else sortFlightsByDestination();
                    break;

                case 6:
                    System.out.print("Flight ID: ");
                    int bid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Passenger Name: ");
                    String pn = sc.nextLine();
                    System.out.print("Age: ");
                    int age = sc.nextInt();
                    bookPassenger(bid, new Passenger(pn, age));
                    break;

                case 7:
                    System.out.print("Flight ID: ");
                    int cid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Passenger Name: ");
                    cancelPassenger(cid, sc.nextLine());
                    break;

                case 8:
                    System.out.print("Flight ID: ");
                    printPassengers(sc.nextInt());
                    break;

                case 9:
                    System.out.print("Flight ID: ");
                    int sid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Passenger Name: ");
                    Passenger found = searchPassengerIterative(sid, sc.nextLine());
                    System.out.println(found != null ? found : "Not found");
                    break;

                case 10:
                    System.out.println("Total passengers: " + totalPassengersAllFlights());
                    break;

                case 11:
                    mostBookedFlight();
                    break;

                case 12:
                    undoLastAction();
                    break;

                case 0:
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
}

        
        
	

